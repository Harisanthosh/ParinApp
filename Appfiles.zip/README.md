# ParinApp
A website presenting a line chart/plot which shows in a time range of 6 hours when the temperature has been above 84.3 degrees

# Tech Stack
Development - Python (Dash, Plotly and Requests)
Continuous Integration - AWS CodePipeline
Infrastructure Provision - AWS Elastic BeanStalk
